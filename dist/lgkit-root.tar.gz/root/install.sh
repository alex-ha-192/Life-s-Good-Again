#!/bin/sh
# LG TV Privacy Kit - installer for ROOTED TVs (Homebrew Channel with root). Runs ON THE TV, as root.
#
# Easiest: from a laptop, once:   python3 setup.py --root          (copies the kit over SSH and runs this)
# By hand, over SSH on the TV:    sh /tmp/kit/root/install.sh --from /tmp/kit [options]
#
# What it sets up (all reversible, nothing on the read-only system partition):
#   - Tiles Home installed, opened by the Home button, at power-on and after standby
#   - the kit's blocklist in the TV's own hosts file (no Pi-hole needed)
#   - a firewall so apps can't go around it (public resolvers, DoH by IP, DNS-over-TLS)
#   - the privacy settings re-checked on the TV every 6 hours and after every power-on
#
# Options:
#   --from DIR          the unpacked kit (default: the folder above this script)
#   --tiers LIST        blocklist tiers, comma list of base,strict,doh (default: base,doh; strict also stops the Content Store)
#   --block-updates     also block LG firmware updates (keeps root; you miss LG's security fixes)
#   --home-code N       your remote's Home key code (find it with: node find-home-key.js)
#   --no-firewall       skip the firewall rules
#   --no-boot-to-tiles  don't open Tiles Home at power-on (the Home button still does)
#   --no-redirect       don't take over LG Home at all
#   --guard-hours N     how often to re-check settings (default 6, 0 = only after power-on)
#   --skip-app          don't install/update the Tiles Home app
#   --status            show what's active
#   --uninstall         remove all of it (Tiles Home itself stays; remove it from the app list)
set -u
D=/var/lib/webosbrew/lgkit
INITD=/var/lib/webosbrew/init.d
APP=io.github.lgprivacykit.tiles
SRC=$(cd "$(dirname "$0")/.." 2>/dev/null && pwd)
TIERS=base,doh; BLOCK_UPDATES=0; HOME_CODE=""; FIREWALL=1; BOOT_TO_TILES=1; REDIRECT_HOME=1
GUARD_HOURS=6; SKIP_APP=0; MODE=install

die() { echo "! $*" >&2; exit 1; }
say() { echo "$*"; }

while [ $# -gt 0 ]; do
    case "$1" in
        --from) SRC=$2; shift ;;
        --tiers) TIERS=$2; shift ;;
        --block-updates) BLOCK_UPDATES=1 ;;
        --home-code) HOME_CODE=$2; shift ;;
        --no-firewall) FIREWALL=0 ;;
        --no-boot-to-tiles) BOOT_TO_TILES=0 ;;
        --no-redirect) REDIRECT_HOME=0 ;;
        --guard-hours) GUARD_HOURS=$2; shift ;;
        --skip-app) SKIP_APP=1 ;;
        --status) MODE=status ;;
        --uninstall) MODE=uninstall ;;
        -h|--help) sed -n '2,27p' "$0"; exit 0 ;;
        *) die "unknown option $1 (try --help)" ;;
    esac
    shift
done

[ "$(id -u)" = 0 ] || die "run this as root on the TV (Homebrew Channel SSH, user root)"
[ -d /var/lib/webosbrew ] || die "Homebrew Channel isn't set up with root on this TV (/var/lib/webosbrew missing)"

stop_agent() {
    for p in $(pgrep -f lgkit-agent.js 2>/dev/null) $(pgrep -f tiles-home-watch.js 2>/dev/null); do kill "$p" 2>/dev/null; done
}
unmount_hosts() {
    if grep -q " /etc/hosts " /proc/mounts; then
        umount /etc/hosts 2>/dev/null && say "  hosts: back to stock" || say "  ! couldn't unmount /etc/hosts (reboot will)"
    fi
}
flush_fw() {
    for T in iptables ip6tables; do
        command -v $T >/dev/null 2>&1 || continue
        while $T -D OUTPUT -j LGKIT 2>/dev/null; do :; done
        $T -F LGKIT 2>/dev/null; $T -X LGKIT 2>/dev/null
    done
}
remove_old_v1() {
    # v1 of the kit shipped these optional hooks; the agent replaces them
    rm -f "$INITD/50-tiles-home" "$INITD/51-tiles-home-watch" /var/lib/webosbrew/tiles-home-watch.js \
          /var/lib/webosbrew/tiles-home.conf
}

if [ "$MODE" = status ]; then
    say "Init hook:  $(ls -l "$INITD/50-lgkit" 2>/dev/null || echo 'not installed')"
    if grep -q " /etc/hosts " /proc/mounts; then say "Hosts:      blocking $(grep -c '^0\.0\.0\.0' /etc/hosts) names"; else say "Hosts:      stock"; fi
    if command -v iptables >/dev/null 2>&1 && iptables -S LGKIT >/dev/null 2>&1; then
        say "Firewall:   $(iptables -S LGKIT | grep -c REJECT) IPv4 rules"; else say "Firewall:   off"; fi
    say "Agent:      $(pgrep -f lgkit-agent.js >/dev/null 2>&1 && echo running || echo 'not running')"
    [ -f "$D/status.json" ] && cat "$D/status.json" && echo
    [ -f "$D/agent.log" ] && { say "Last log lines:"; tail -n 8 "$D/agent.log"; }
    exit 0
fi

if [ "$MODE" = uninstall ]; then
    say "Removing the LG TV Privacy Kit from this TV"
    rm -f "$INITD/50-lgkit"; remove_old_v1
    stop_agent; say "  agent: stopped"
    unmount_hosts
    flush_fw; say "  firewall: removed"
    rm -rf "$D"
    say "Done. Tiles Home is still installed: remove it from the app list if you don't want it."
    say "The privacy settings stay as they are; turn any back on in the TV's settings."
    exit 0
fi

# ------------------------------------------------------------------ install
[ -f "$SRC/root/lgkit-agent.js" ] || die "kit not found at $SRC (use --from DIR)"
command -v node >/dev/null 2>&1 || die "no node on this TV; the agent needs it"
say "Installing the LG TV Privacy Kit (rooted) from $SRC"
mkdir -p "$D" "$INITD" || die "can't create $D"

# blocklist
tmp=$D/hosts.block.new
: >"$tmp"
for t in $(echo "$TIERS" | tr ',' ' '); do
    f=$SRC/blocklist/lg-$t.hosts
    [ -s "$f" ] || die "no blocklist for tier $t ($f)"
    grep -E '^0\.0\.0\.0[[:space:]]+[A-Za-z0-9._-]+$' "$f" >>"$tmp"
done
[ "$BLOCK_UPDATES" = 1 ] && grep -E '^0\.0\.0\.0[[:space:]]' "$SRC/blocklist/lg-firmware-updates.hosts" >>"$tmp"
sort -u "$tmp" >"$D/hosts.block" && rm -f "$tmp"
say "  blocklist: $(wc -l <"$D/hosts.block") names (tiers: $TIERS$([ "$BLOCK_UPDATES" = 1 ] && echo ', firmware updates'))"

# agent, boot hook, settings
cp "$SRC/root/lgkit-agent.js" "$SRC/root/lgkit-boot.sh" "$SRC/root/find-home-key.js" "$SRC/root/install.sh" "$D/" || die "copy failed"
[ -s "$SRC/root/settings.json" ] && cp "$SRC/root/settings.json" "$D/"
chmod 755 "$D/lgkit-boot.sh" "$D/install.sh"
if [ -z "$HOME_CODE" ] && [ -f "$D/lgkit.env" ]; then HOME_CODE=$(sed -n 's/^HOME_CODE=//p' "$D/lgkit.env"); fi
cat >"$D/lgkit.env" <<EOF
# written by install.sh; edit and reboot (or re-run install.sh) to change
TILES_APP=$APP
HOSTS=1
FIREWALL=$FIREWALL
BOOT_TO_TILES=$BOOT_TO_TILES
REDIRECT_HOME=$REDIRECT_HOME
GUARD_HOURS=$GUARD_HOURS
HOME_CODE=${HOME_CODE:-0}
EOF

remove_old_v1
ln -sf "$D/lgkit-boot.sh" "$INITD/50-lgkit"
say "  boot hook: $INITD/50-lgkit"

# Tiles Home app
if [ "$SKIP_APP" = 0 ]; then
    ipk=$(ls -t "$SRC"/dist/*.ipk 2>/dev/null | head -n1)
    if [ -n "$ipk" ]; then
        mkdir -p /media/developer/temp
        cp "$ipk" /media/developer/temp/lgkit-tiles.ipk
        r=$(luna-send -n 1 -w 30000 luna://com.webos.appInstallService/dev/install \
            '{"id":"com.ares.defaultName","ipkUrl":"/media/developer/temp/lgkit-tiles.ipk","subscribe":true}' 2>&1)
        case "$r" in
            *'"returnValue":true'*|*'"returnValue": true'*) say "  Tiles Home: installed from $(basename "$ipk")" ;;
            *) say "  ! Tiles Home install said: $r"; say "    Install the .ipk from Homebrew Channel or Dev Manager instead." ;;
        esac
    else
        say "  Tiles Home: no .ipk in $SRC/dist, skipping (build it with tools/build_ipk.py)"
    fi
fi

# apply now: restart cleanly so new settings take effect
stop_agent; unmount_hosts; flush_fw
LGKIT_FIRST_BOOT=1 sh "$D/lgkit-boot.sh"
sleep 1
tail -n 6 "$D/boot.log" | sed 's/^/  /'
say ""
say "Done. Press Home on the remote: Tiles Home should open."
[ "${HOME_CODE:-0}" = 0 ] && say "Tip: run 'node $D/find-home-key.js', press Home, then re-run with --home-code N so the Home button is caught even faster."
say "Status any time: sh $D/install.sh --status    Undo: sh $D/install.sh --uninstall"
